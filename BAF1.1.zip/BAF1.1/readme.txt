1. install docker https://docs.docker.com/engine/install/
2. unzip BAF1.1.zip
3. open terminal and move to BAF1.1 folder usind cd
4. run "run_BAF_docker.sh <sample_name> <raw_reads_folder>" using bash command 
	e.g. "bash run_BAF_docker.sh example_name /home/user/Downloads/raw_reads"

general remarks:

raw_reads_folder must contain paired illumina read files ending with *R1_001.fastq.gz and *R2_001.fastq.gz.
Once image is installed 4. can (hopefully) be used for any illumina sample.

if no contig.fasta file has been generated in assembly folder there may be too few reads that have been aligned to transporter/decarboxylase sequences for a successful assembly.

To be able to open assembled contigs.fasta files in IGV copy the file to a folder with writing permission or change permission of results folder as superuser e.g. "sudo chmod -R 777 example_name/"
