#!/bin/bash
#sample_name=Alp
#raw_reads_folder=/home/maro/Downloads/0_raw_reads/


sample_name=$1
raw_reads_folder=$2

#cd ${0%/*}
docker run -v "${raw_reads_folder}:/home/reads_folder" -v "$(pwd)/results/${sample_name}:/results/sample" marowidmer/baf:v1.1 /BAF_program/BAF.sh

